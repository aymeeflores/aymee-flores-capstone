import React from "react";
import "./Feed.scss";

export default function Feed() {
  return (
    <>
      <div className="feed">
        <h1>feed</h1>
      </div>
    </>
  );
}

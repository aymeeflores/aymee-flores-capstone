import React from "react";

export default function Rightbar() {
  return (
    <>
      <div className="rightbar">
        <h1>Rightbar</h1>
      </div>
    </>
  );
}
